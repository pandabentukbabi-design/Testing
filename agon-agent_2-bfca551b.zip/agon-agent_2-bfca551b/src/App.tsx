import { useMemo, useState } from 'react'
import { motion } from 'framer-motion'
import {
  Award,
  BookOpen,
  BriefcaseBusiness,
  Building2,
  CalendarDays,
  ChevronRight,
  GraduationCap,
  MapPin,
  Menu,
  Microscope,
  Phone,
  Send,
  ShieldCheck,
  Sparkles,
  Star,
  Users,
  X,
} from 'lucide-react'
import './App.css'

function App() {
  const [menuOpen, setMenuOpen] = useState(false)
  const [selectedProgram, setSelectedProgram] = useState('Agribisnis Tanaman')

  const navItems = ['Beranda', 'Profil', 'Program', 'Fasilitas', 'Prestasi', 'Kontak']
  const programs = useMemo(
    () => [
      {
        name: 'Agribisnis Tanaman',
        icon: <Sparkles className="h-6 w-6" />,
        description:
          'Pembelajaran budidaya tanaman pangan, hortikultura, dan manajemen green house berbasis praktik industri.',
        skills: ['Budidaya modern', 'Green house', 'Kewirausahaan hasil tani'],
      },
      {
        name: 'Teknik Komputer & Jaringan',
        icon: <Microscope className="h-6 w-6" />,
        description:
          'Membekali peserta didik dengan kompetensi jaringan, perakitan komputer, cloud dasar, dan layanan IT sekolah.',
        skills: ['Administrasi jaringan', 'IoT sekolah', 'Troubleshooting'],
      },
      {
        name: 'Bisnis Digital',
        icon: <BriefcaseBusiness className="h-6 w-6" />,
        description:
          'Mengembangkan kemampuan pemasaran digital, desain konten, pengelolaan toko online, dan layanan pelanggan.',
        skills: ['Marketplace', 'Konten kreatif', 'Analitik penjualan'],
      },
    ],
    [],
  )

  const activeProgram = programs.find((program) => program.name === selectedProgram) ?? programs[0]

  const scrollToSection = (id: string) => {
    document.getElementById(id.toLowerCase())?.scrollIntoView({ behavior: 'smooth' })
    setMenuOpen(false)
  }

  return (
    <main className="min-h-screen bg-[#f7fbf3] text-slate-900">
      <div className="fixed inset-x-0 top-0 z-50 border-b border-white/30 bg-white/85 shadow-sm backdrop-blur-xl">
        <nav className="mx-auto flex max-w-7xl items-center justify-between px-5 py-3 lg:px-8">
          <button onClick={() => scrollToSection('beranda')} className="flex items-center gap-3 text-left">
            <div className="grid h-12 w-12 place-items-center rounded-2xl bg-gradient-to-br from-emerald-600 to-lime-500 text-white shadow-lg shadow-emerald-700/20">
              <GraduationCap className="h-7 w-7" />
            </div>
            <div>
              <p className="text-sm font-black uppercase tracking-[0.25em] text-emerald-700">SMK Nusantara</p>
              <p className="text-xs font-semibold text-slate-500">Sekolah Vokasi Unggul</p>
            </div>
          </button>

          <div className="hidden items-center gap-1 lg:flex">
            {navItems.map((item) => (
              <button
                key={item}
                onClick={() => scrollToSection(item)}
                className="rounded-full px-4 py-2 text-sm font-bold text-slate-600 transition hover:bg-emerald-50 hover:text-emerald-700"
              >
                {item}
              </button>
            ))}
          </div>

          <button
            onClick={() => scrollToSection('kontak')}
            className="hidden rounded-full bg-slate-950 px-5 py-3 text-sm font-bold text-white shadow-xl shadow-slate-900/15 transition hover:-translate-y-0.5 hover:bg-emerald-700 lg:inline-flex"
          >
            Daftar Sekarang
          </button>

          <button
            aria-label="Buka menu"
            onClick={() => setMenuOpen((value) => !value)}
            className="rounded-2xl border border-slate-200 p-3 lg:hidden"
          >
            {menuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </button>
        </nav>

        {menuOpen && (
          <div className="border-t border-slate-100 bg-white px-5 py-4 lg:hidden">
            <div className="mx-auto grid max-w-7xl gap-2">
              {navItems.map((item) => (
                <button
                  key={item}
                  onClick={() => scrollToSection(item)}
                  className="rounded-2xl px-4 py-3 text-left font-bold text-slate-700 hover:bg-emerald-50"
                >
                  {item}
                </button>
              ))}
            </div>
          </div>
        )}
      </div>

      <section id="beranda" className="relative overflow-hidden px-5 pb-20 pt-32 lg:px-8 lg:pb-28 lg:pt-40">
        <div className="absolute left-0 top-20 h-72 w-72 rounded-full bg-lime-200/60 blur-3xl" />
        <div className="absolute bottom-12 right-0 h-96 w-96 rounded-full bg-emerald-200/50 blur-3xl" />
        <div className="relative mx-auto grid max-w-7xl items-center gap-12 lg:grid-cols-[1.05fr_0.95fr]">
          <motion.div initial={{ opacity: 0, y: 24 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.7 }}>
            <div className="mb-6 inline-flex items-center gap-2 rounded-full border border-emerald-200 bg-white px-4 py-2 text-sm font-bold text-emerald-700 shadow-sm">
              <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
              Penerimaan Peserta Didik Baru 2026 Telah Dibuka
            </div>
            <h1 className="max-w-4xl text-5xl font-black leading-[0.98] tracking-tight text-slate-950 md:text-7xl">
              Sekolah vokasi yang menyiapkan generasi siap kerja, santun, dan inovatif.
            </h1>
            <p className="mt-6 max-w-2xl text-lg leading-8 text-slate-600">
              Website pengenalan sekolah bergaya modern untuk menampilkan profil, program keahlian, fasilitas,
              prestasi, berita, serta jalur pendaftaran secara jelas seperti portal sekolah profesional.
            </p>
            <div className="mt-8 flex flex-col gap-3 sm:flex-row">
              <button
                onClick={() => scrollToSection('program')}
                className="inline-flex items-center justify-center gap-2 rounded-full bg-emerald-700 px-7 py-4 font-black text-white shadow-xl shadow-emerald-700/25 transition hover:-translate-y-1 hover:bg-emerald-800"
              >
                Lihat Program Keahlian <ChevronRight className="h-5 w-5" />
              </button>
              <button
                onClick={() => scrollToSection('profil')}
                className="inline-flex items-center justify-center rounded-full border border-slate-200 bg-white px-7 py-4 font-black text-slate-800 transition hover:-translate-y-1 hover:border-emerald-300 hover:text-emerald-700"
              >
                Kenali Sekolah
              </button>
            </div>
            <div className="mt-10 grid max-w-2xl grid-cols-3 gap-3">
              {[
                ['1.250+', 'Siswa Aktif'],
                ['38', 'Guru Produktif'],
                ['96%', 'Lulusan Terserap'],
              ].map(([value, label]) => (
                <div key={label} className="rounded-3xl border border-white bg-white/75 p-4 shadow-sm backdrop-blur">
                  <p className="text-2xl font-black text-emerald-700 md:text-3xl">{value}</p>
                  <p className="text-xs font-bold uppercase tracking-wide text-slate-500">{label}</p>
                </div>
              ))}
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, scale: 0.94 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.7, delay: 0.15 }}
            className="relative"
          >
            <div className="absolute -left-5 top-10 z-10 rounded-3xl bg-white p-4 shadow-2xl shadow-slate-900/15">
              <div className="flex items-center gap-3">
                <div className="grid h-11 w-11 place-items-center rounded-2xl bg-yellow-100 text-yellow-700">
                  <Award className="h-6 w-6" />
                </div>
                <div>
                  <p className="font-black">Akreditasi A</p>
                  <p className="text-sm text-slate-500">Berbasis mutu & karakter</p>
                </div>
              </div>
            </div>
            <div className="overflow-hidden rounded-[2.5rem] border-8 border-white bg-white shadow-2xl shadow-emerald-950/20">
              <img src="/images/school-hero.jpg" alt="Siswa sekolah mengikuti pembelajaran" className="h-[560px] w-full object-cover" />
            </div>
            <div className="absolute -bottom-8 right-6 rounded-3xl bg-slate-950 p-5 text-white shadow-2xl">
              <p className="text-sm font-bold text-emerald-200">Mitra industri</p>
              <p className="text-3xl font-black">25+</p>
            </div>
          </motion.div>
        </div>
      </section>

      <section id="profil" className="bg-white px-5 py-20 lg:px-8">
        <div className="mx-auto grid max-w-7xl gap-12 lg:grid-cols-[0.9fr_1.1fr]">
          <div className="overflow-hidden rounded-[2rem] bg-emerald-100 p-3">
            <img src="/images/campus.jpg" alt="Gedung dan lingkungan sekolah" className="h-full min-h-[430px] w-full rounded-[1.5rem] object-cover" />
          </div>
          <div className="flex flex-col justify-center">
            <p className="font-black uppercase tracking-[0.3em] text-emerald-700">Profil Sekolah</p>
            <h2 className="mt-3 text-4xl font-black tracking-tight text-slate-950 md:text-5xl">
              Lingkungan belajar yang religius, produktif, dan dekat dengan dunia kerja.
            </h2>
            <p className="mt-5 text-lg leading-8 text-slate-600">
              SMK Nusantara dirancang sebagai contoh website pengenalan sekolah: lengkap dengan visi-misi,
              keunggulan, fasilitas praktik, program keahlian, agenda, dan kontak pendaftaran. Konten dapat
              disesuaikan untuk nama sekolah, alamat, jurusan, dan data asli.
            </p>
            <div className="mt-8 grid gap-4 sm:grid-cols-2">
              {[
                { icon: <ShieldCheck />, title: 'Karakter & Disiplin', text: 'Pembiasaan positif, budaya salam, dan pembinaan akhlak.' },
                { icon: <BookOpen />, title: 'Kurikulum Merdeka', text: 'Project based learning sesuai kebutuhan industri.' },
                { icon: <Users />, title: 'Guru Berpengalaman', text: 'Tim pendidik produktif dan adaptif teknologi.' },
                { icon: <Building2 />, title: 'Teaching Factory', text: 'Unit produksi untuk praktik dan portofolio siswa.' },
              ].map((item) => (
                <div key={item.title} className="rounded-3xl border border-slate-100 bg-slate-50 p-5">
                  <div className="mb-4 grid h-12 w-12 place-items-center rounded-2xl bg-emerald-100 text-emerald-700">{item.icon}</div>
                  <h3 className="font-black text-slate-950">{item.title}</h3>
                  <p className="mt-2 text-sm leading-6 text-slate-600">{item.text}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      <section id="program" className="px-5 py-20 lg:px-8">
        <div className="mx-auto max-w-7xl">
          <div className="mx-auto max-w-3xl text-center">
            <p className="font-black uppercase tracking-[0.3em] text-emerald-700">Program Keahlian</p>
            <h2 className="mt-3 text-4xl font-black tracking-tight text-slate-950 md:text-5xl">Pilih kompetensi masa depanmu</h2>
            <p className="mt-5 text-slate-600">Klik salah satu program untuk melihat fokus pembelajaran dan kompetensi utama.</p>
          </div>
          <div className="mt-10 grid gap-4 lg:grid-cols-3">
            {programs.map((program) => (
              <button
                key={program.name}
                onClick={() => setSelectedProgram(program.name)}
                className={`rounded-[2rem] border p-6 text-left transition hover:-translate-y-1 ${
                  selectedProgram === program.name
                    ? 'border-emerald-500 bg-emerald-700 text-white shadow-2xl shadow-emerald-700/20'
                    : 'border-slate-200 bg-white text-slate-900 shadow-sm hover:border-emerald-200'
                }`}
              >
                <div className={`mb-5 grid h-14 w-14 place-items-center rounded-2xl ${selectedProgram === program.name ? 'bg-white/20' : 'bg-emerald-100 text-emerald-700'}`}>
                  {program.icon}
                </div>
                <h3 className="text-xl font-black">{program.name}</h3>
                <p className={`mt-3 text-sm leading-6 ${selectedProgram === program.name ? 'text-emerald-50' : 'text-slate-600'}`}>{program.description}</p>
              </button>
            ))}
          </div>
          <div className="mt-8 grid gap-8 rounded-[2.5rem] bg-slate-950 p-6 text-white shadow-2xl shadow-slate-950/20 lg:grid-cols-[0.85fr_1.15fr] lg:p-8">
            <img src="/images/students-lab.jpg" alt="Siswa belajar di laboratorium komputer" className="h-80 w-full rounded-[2rem] object-cover" />
            <div className="flex flex-col justify-center">
              <p className="text-sm font-black uppercase tracking-[0.25em] text-emerald-300">Detail Program</p>
              <h3 className="mt-3 text-3xl font-black">{activeProgram.name}</h3>
              <p className="mt-4 max-w-2xl leading-7 text-slate-300">{activeProgram.description}</p>
              <div className="mt-6 flex flex-wrap gap-3">
                {activeProgram.skills.map((skill) => (
                  <span key={skill} className="rounded-full bg-white/10 px-4 py-2 text-sm font-bold text-white ring-1 ring-white/10">
                    {skill}
                  </span>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      <section id="fasilitas" className="bg-white px-5 py-20 lg:px-8">
        <div className="mx-auto max-w-7xl">
          <div className="flex flex-col justify-between gap-6 md:flex-row md:items-end">
            <div>
              <p className="font-black uppercase tracking-[0.3em] text-emerald-700">Fasilitas</p>
              <h2 className="mt-3 text-4xl font-black tracking-tight md:text-5xl">Ruang belajar yang mendukung praktik nyata</h2>
            </div>
            <button onClick={() => scrollToSection('kontak')} className="rounded-full bg-emerald-700 px-6 py-4 font-black text-white transition hover:bg-emerald-800">
              Jadwalkan Kunjungan
            </button>
          </div>
          <div className="mt-10 grid gap-5 md:grid-cols-2 lg:grid-cols-4">
            {[
              ['Laboratorium Komputer', 'Perangkat jaringan, server mini, dan kelas digital.'],
              ['Green House', 'Area praktik pertanian modern dan pembibitan.'],
              ['Perpustakaan Digital', 'Literasi, e-book, dan pojok riset siswa.'],
              ['Lapangan & Aula', 'Kegiatan olahraga, seni, organisasi, dan upacara.'],
            ].map(([title, text], index) => (
              <div key={title} className="group rounded-[2rem] border border-slate-100 bg-slate-50 p-6 transition hover:-translate-y-1 hover:bg-emerald-700 hover:text-white">
                <p className="text-5xl font-black text-emerald-200 transition group-hover:text-white/20">0{index + 1}</p>
                <h3 className="mt-8 text-xl font-black">{title}</h3>
                <p className="mt-3 leading-6 text-slate-600 transition group-hover:text-emerald-50">{text}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section id="prestasi" className="px-5 py-20 lg:px-8">
        <div className="mx-auto max-w-7xl rounded-[2.5rem] bg-gradient-to-br from-emerald-800 to-slate-950 p-8 text-white lg:p-12">
          <div className="grid gap-10 lg:grid-cols-[0.8fr_1.2fr]">
            <div>
              <p className="font-black uppercase tracking-[0.3em] text-emerald-200">Prestasi & Agenda</p>
              <h2 className="mt-3 text-4xl font-black tracking-tight md:text-5xl">Sekolah aktif, siswa berprestasi.</h2>
              <p className="mt-5 leading-7 text-emerald-50/80">
                Bagian ini cocok untuk menampilkan berita sekolah, pengumuman PPDB, lomba, kerja sama industri, dan galeri kegiatan.
              </p>
            </div>
            <div className="grid gap-4">
              {[
                ['Juara 1 LKS Tingkat Kabupaten', 'Tim produktif meraih penghargaan bidang teknologi dan agribisnis.'],
                ['Kunjungan Industri & Magang', 'Siswa kelas XI mengikuti program praktik kerja lapangan bersama mitra.'],
                ['Expo Karya Siswa', 'Produk budidaya, desain konten, dan layanan IT dipamerkan kepada masyarakat.'],
              ].map(([title, text]) => (
                <article key={title} className="rounded-3xl bg-white/10 p-5 ring-1 ring-white/10 backdrop-blur">
                  <div className="flex gap-4">
                    <div className="grid h-12 w-12 shrink-0 place-items-center rounded-2xl bg-yellow-400 text-slate-950">
                      <CalendarDays className="h-6 w-6" />
                    </div>
                    <div>
                      <h3 className="font-black">{title}</h3>
                      <p className="mt-2 text-sm leading-6 text-emerald-50/75">{text}</p>
                    </div>
                  </div>
                </article>
              ))}
            </div>
          </div>
        </div>
      </section>

      <section id="kontak" className="bg-white px-5 py-20 lg:px-8">
        <div className="mx-auto grid max-w-7xl gap-8 lg:grid-cols-[0.9fr_1.1fr]">
          <div>
            <p className="font-black uppercase tracking-[0.3em] text-emerald-700">Kontak & PPDB</p>
            <h2 className="mt-3 text-4xl font-black tracking-tight md:text-5xl">Ayo mulai perjalananmu bersama kami.</h2>
            <div className="mt-8 grid gap-4">
              {[
                { icon: <MapPin />, title: 'Alamat', text: 'Jl. Pendidikan No. 12, Pasirjambu, Bandung, Jawa Barat' },
                { icon: <Phone />, title: 'Telepon', text: '(022) 1234 5678 / 0812-0000-2026' },
                { icon: <Send />, title: 'Email', text: 'info@smknusantara.sch.id' },
              ].map((item) => (
                <div key={item.title} className="flex gap-4 rounded-3xl border border-slate-100 bg-slate-50 p-5">
                  <div className="grid h-12 w-12 shrink-0 place-items-center rounded-2xl bg-emerald-100 text-emerald-700">{item.icon}</div>
                  <div>
                    <p className="font-black">{item.title}</p>
                    <p className="mt-1 text-slate-600">{item.text}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <form
            onSubmit={(event) => {
              event.preventDefault()
              alert('Terima kasih! Data minat pendaftaran berhasil disimulasikan. Admin sekolah akan menghubungi Anda.')
            }}
            className="rounded-[2.5rem] bg-slate-950 p-6 text-white shadow-2xl shadow-slate-950/20 lg:p-8"
          >
            <h3 className="text-2xl font-black">Form Minat Pendaftaran</h3>
            <p className="mt-2 text-slate-300">Isi data singkat berikut untuk simulasi CTA pendaftaran sekolah.</p>
            <div className="mt-6 grid gap-4">
              <input required placeholder="Nama lengkap calon siswa" className="rounded-2xl border border-white/10 bg-white/10 px-5 py-4 outline-none placeholder:text-slate-400 focus:border-emerald-300" />
              <input required type="tel" placeholder="Nomor WhatsApp" className="rounded-2xl border border-white/10 bg-white/10 px-5 py-4 outline-none placeholder:text-slate-400 focus:border-emerald-300" />
              <select className="rounded-2xl border border-white/10 bg-white/10 px-5 py-4 outline-none focus:border-emerald-300">
                {programs.map((program) => (
                  <option key={program.name} className="text-slate-900">{program.name}</option>
                ))}
              </select>
              <textarea placeholder="Pesan atau pertanyaan" rows={4} className="rounded-2xl border border-white/10 bg-white/10 px-5 py-4 outline-none placeholder:text-slate-400 focus:border-emerald-300" />
              <button className="rounded-full bg-yellow-400 px-7 py-4 font-black text-slate-950 transition hover:-translate-y-1 hover:bg-yellow-300">
                Kirim Minat Pendaftaran
              </button>
            </div>
          </form>
        </div>
      </section>

      <footer className="bg-slate-950 px-5 py-8 text-white lg:px-8">
        <div className="mx-auto flex max-w-7xl flex-col justify-between gap-4 text-sm text-slate-400 md:flex-row">
          <p>© 2026 SMK Nusantara. Template website pengenalan sekolah.</p>
          <p>Dibuat modern, responsif, dan siap dikustomisasi.</p>
        </div>
      </footer>
    </main>
  )
}

export default App
